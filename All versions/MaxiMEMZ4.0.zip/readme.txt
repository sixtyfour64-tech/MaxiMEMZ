This is malicious software.
Do not run unless you know the risks.